Sarudi Platformer — minimal revision

Replace your existing app.js and game.html with these files.
Copy the included assets/spritesheet.png into your project's assets folder.
Keep your existing assets/cloud1.png, cloud2.png, cloud3.png, sarudi.png, and add/keep
assets/spritesheetL.png (the left-facing/flipped 8-frame sheet).

Important fixes:
- Jump input is buffered for 9 frames and coyote time is 8 frames.
- Key-repeat no longer spams jump; each fresh press creates one jump request.
- Landing resets the grounded state correctly, so repeated jumps work.
- The sprite animation reads one 64x64 frame at a time from the right or left sheet.
- Camera scrolling only changes drawing coordinates; collision and level coordinates remain world-based.
- E opens the small tile editor. Click to place; right-click to erase.
- Editor Save/Load stores the tile map in this browser's localStorage.

Controls: A/D or arrows move; Space/W/Up jump; E editor; R respawn.
Tile IDs: 0 erase, 1 ground, 2 spring, 3 stone, 4 spikes, 5 checkpoint, 6 goal.
